local deviceName = "LaunchpadMiniMK3" -- must match the file name
local port = 0 -- the one LPMiniMK3 MIDI output (order of output= lines in the .ini)
local dev = LaunchpadMiniMK3
local GRID_NOTE0 = 11 -- notes 11-88, bottom-left first (10-note blocks)
local GRID_COLS, GRID_ROWS = 8, 8
local TOP = {
up = 91,
down = 92,
left = 93,
right = 94,
session = 95,
drums = 96,
keys = 97,
user = 98,
}
local SCENE = { 89, 79, 69, 59, 49, 39, 29 } -- scene buttons, top to bottom (rows 0-6)
local MENU = 19 -- bottom-right corner button: the MIXER menu
local SYSEX_MAX_SPECS = 81 -- the whole surface (64 pads + 8 top + 8 right)
local ACTIONS = {
[91] = { label = "Up", plain = "window up / page value up (hold repeats)" },
[92] = { label = "Down", plain = "window down / page value down (hold repeats)" },
[93] = { label = "Left", plain = "move the clip window left (sends menu: previous send)" },
[94] = { label = "Right", plain = "move the clip window right (sends menu: next send)" },
[95] = { label = "Session", plain = "clip grid (leaves every page)" },
[96] = { label = "Drums", plain = "pads mode; repeat: 16-pad quadrant <-> 64 pads, then off" },
[97] = { label = "Keys", plain = "play the track's pads from the grid — kits plainly, melodic tracks with Pad Perform chords (repeat: leave)" },
[98] = { label = "User", plain = "Q-Link page (repeat: page 2, then exit)" },
[89] = { label = "Scene 1", plain = "launch scene 1" },
[79] = { label = "Scene 2", plain = "launch scene 2" },
[69] = { label = "Scene 3", plain = "launch scene 3" },
[59] = { label = "Scene 4", plain = "launch scene 4" },
[49] = { label = "Scene 5", plain = "launch scene 5" },
[39] = { label = "Scene 6", plain = "launch scene 6" },
[29] = { label = "Scene 7", plain = "launch scene 7" },
[19] = { label = "Mixer", plain = "open/close the MIXER menu (grid)" },
}
local MIXER = {
{ row = 0, label = "Pages (global, not per track)", items = { "Volume (cyan tint)", "Pan (magenta tint)", "Send — cycles 1-4 on the arrows (tint follows the send)", "Tempo page (white)", "Swing page (yellow)", "Q-Link page (blue tint)", "Tap tempo (grey)", "Click — cyan while the metronome runs" } },
{ row = 1, label = "Transport (global, not per track)", items = { "Play (green playing, orange loop armed)", "Record (red)", "Stop (stop; stop again = return to zero)" } },
{ row = 2, label = "Record (blue; red while recording, dim red armed)", perTrack = true },
{ row = 3, label = "Stop clips (grey)", perTrack = true },
{ row = 4, label = "Mute (orange)", perTrack = true },
{ row = 5, label = "Solo (yellow)", perTrack = true },
{ row = 6, label = "Record arm (red)", perTrack = true },
{ row = 7, label = "Select track (track colour, white = current)", perTrack = true },
}
local MIX_STRIP_KEYS = {
[0] = { "volume", "pan", "send", "tempo", "swing", "qlink", "tap", "click" },
[1] = { "play", "record", "stop" },
}
local S = {
NoSlot = 0,
Empty = 1,
Ready = 2,
WillPlay = 3,
Playing = 4,
WillStopPlaying = 5,
WillRecord = 6,
Recording = 7,
WillStopRecording = 8,
WillOverdub = 9,
Overdubbing = 10,
WillStopOverdubbing = 11,
}
local C = {
off = { 0, 0, 0 },
dim = { 12, 12, 12 },
available = { 60, 60, 60 },
white = { 127, 127, 127 },
green = { 0, 127, 0 },
red = { 127, 0, 0 },
orange = { 127, 60, 0 },
blue = { 0, 60, 127 },
cyan = { 0, 127, 127 },
magenta = { 127, 0, 127 },
yellow = { 127, 127, 0 },
}
local VOLUME_DB = { [7] = -100, [6] = -30, [5] = -20, [4] = -9, [3] = -3, [2] = 0, [1] = 3, [0] = 6 }
local SEND_COLOURS = { C.yellow, C.green, C.blue, C.orange }
local DIM_RED = { 30, 0, 0 }
local DIM_YELLOW = { 22, 22, 0 }
local DIM_ORANGE = { 35, 16, 0 }
local DIM_CYAN = { 0, 22, 22 }
local DIM_MAGENTA = { 22, 0, 22 }
local DIM_TEMPO = { 20, 20, 20 }
local DIM_QLINK = { 10, 0, 30 }
local DIM_SEND = { { 22, 22, 0 }, { 0, 22, 0 }, { 0, 0, 22 }, { 22, 10, 0 } }
local aperture, clipProps
local originCol, originRow = 0, 0
local padCache = {} -- LED index -> "r,g,b" last sent
local ledSpecs = {} -- accumulated specs for the current flush
local ticks = 0
local blinkOn = false
local adjustMode = nil -- nil / "volume" / "pan" / "sends" (menu mode)
local adjustSend = 1 -- 1..4, the active send in sends mode
local adjustCol = 0 -- last grid column touched in the menu (for up/down nudges)
local lastPadCol, lastPadRow, lastPadTick = nil, nil, -100
local tempoMode = false -- tempo page: up/down change BPM
local tempoHold = nil -- TOP.up / TOP.down while held (auto-repeat)
local tempoHoldTicks = 0 -- ticks since the tempo button was pressed
local swingMode = false -- swing page: up/down change swing
local swingHold = nil -- TOP.up / TOP.down while held (auto-repeat)
local swingHoldTicks = 0 -- ticks since the swing button was pressed
local qlinkMode = false -- CC98 user page: Q-Link faders (Twist-driven)
local qlinkPage = 0 -- 0 = Q-Links 0-7, 1 = Q-Links 8-15
local qlinkCol = 0 -- last grid column touched (for Shift+up/down nudges)
local padsMode = false -- CC96 MPC pads mode: the grid quadrant mirrors mpc.controlSurface.pads
local padsColourCache = {} -- pad index -> ARGB int last sent (diff-only mirror)
local tapTicks = {} -- recent tap-tempo tick timestamps (50 ms per tick)
local padsLayout = "drum" -- CC 96 mode layout: drum (4x4 bank A) or pads64 (all four banks)
local padsSwitched = false -- Drums pressed once in-mode: the layout flipped, next press exits
local keysPage = false -- Keys (CC 97) opened the keys page with pads mode
local keysPP = false -- we engaged the MPC's Pad Perform mode (melodic tracks only)
local trackIsMelodicFn = function()
return false
end -- forward declaration; redefined next to firstLayoutForTrack
local function padPerformPageOurs()
return keysPage and keysPP and trackIsMelodicFn()
end
local boundPadNotes = {} -- grid notes currently routed away from the script
local chromaticVirtualPad -- forward declaration (defined with the pad-mode helpers)
local mixerMode = false -- CC19 MIXER menu owns the grid
local priorMode, priorLayout = nil, nil -- captured from the readback replies
local priorFeedback = nil -- { internal, external } captured before we change it
local programmerEntered = false
local modeQuerySent = false
local lastLog = {}
local H = {}
function H.log(msg)
pcall(function()
print(deviceName .. ": " .. tostring(msg))
end)
end
function H.logOnce(key, msg)
if lastLog[key] then
return
end
lastLog[key] = true
H.log(msg)
end
function H.call(f, ...)
if type(f) ~= "function" then
return nil
end
local ok, r = pcall(f, ...)
if ok then
return r
end
return nil
end
function H.propValue(obj, name)
local p = obj and obj[name]
if p == nil then
return nil
end
local ok, v = pcall(function()
return p.value
end)
if ok then
return v
end
return nil
end
function H.truthy(v)
return v ~= nil and v ~= false and v ~= 0
end
function H.member(obj, key, kind)
if obj == nil then
return nil
end
local v = obj[key]
if v ~= nil and (kind == nil or type(v) == kind) then
return v
end
return nil
end
function H.callable(obj, key)
return H.member(obj, key, "function")
end
function H.trackAction(field, logKey, label)
local ct = mpc.tracks and mpc.tracks.currentTrack
local f = H.callable(ct, field)
if not f then
H.logOnce(logKey, label .. " unavailable: currentTrack." .. field .. " missing")
return false
end
H.call(f)
return true
end
function H.currentPopup()
local em = mpc.engineMode
local p = H.propValue(em, "CurrentPopup")
if p == nil then
p = H.call(H.callable(em, "GetCurrentPopup"))
end
return tostring(p or "")
end
function H.popupOpen()
local p = H.currentPopup()
if p == "" or p == "No Popup" then
return false
end
if padPerformPageOurs() and p == "Pad Perform" then
return false
end
return true
end
function H.projectLoaded()
if H.popupOpen() then
return false
end
if mpc.currentSequence ~= nil then
return true
end
local tracks = mpc.tracks
if tracks ~= nil and tracks.currentTrack ~= nil then
return true
end
local bpm = H.call(H.callable(mpc.sequencer, "GetBPM"))
if type(bpm) == "number" and bpm > 0 then
return true
end
return false
end
function H.requireProject(label)
if H.projectLoaded() then
return true
end
if H.popupOpen() then
H.logOnce(label .. "-popup", label .. ": dialog open (" .. H.currentPopup() .. ")")
else
H.logOnce(label .. "-noproject", label .. ": no project loaded")
end
return false
end
function H.clamp01(v)
v = tonumber(v) or 0
if v < 0 then
return 0
elseif v > 1 then
return 1
end
return v
end
function H.dbToRow(db)
db = tonumber(db)
if db == nil or db <= -60 then
return 7
elseif db <= -25 then
return 6
elseif db <= -14.5 then
return 5
elseif db <= -6 then
return 4
elseif db <= -1.5 then
return 3
elseif db <= 1.5 then
return 2
elseif db <= 4.5 then
return 1
end
return 0
end
function H.dbToGain(db)
db = tonumber(db)
if db == nil or db <= -60 then
return 0
end
return 10 ^ ((db - 6) / 40)
end
function H.gainToDb(gain)
gain = tonumber(gain)
if gain == nil or gain <= 0 then
return -100
end
return 40 * math.log(gain, 10) + 6
end
function H.trackAt(idx)
return mpc.tracks and mpc.tracks.normalTracks and mpc.tracks.normalTracks[idx]
end
function H.adjustPropName()
if adjustMode == "volume" then
return "Volume"
elseif adjustMode == "pan" then
return "Pan"
elseif adjustMode == "sends" then
return "Send" .. adjustSend
end
return nil
end
function H.adjustColour()
if adjustMode == "pan" then
return C.magenta
elseif adjustMode == "sends" then
return SEND_COLOURS[adjustSend] or C.yellow
end
return C.cyan
end
function H.argb(c)
c = tonumber(c) or 0
return math.floor(c / 65536) % 256, math.floor(c / 256) % 256, c % 256
end
function H.scale7(v)
v = tonumber(v) or 0
if v < 0 then
v = 0
elseif v > 255 then
v = 255
end
return math.floor(v * 127 / 255)
end
function H.rgbKey(r, g, b)
return r .. "," .. g .. "," .. b
end
function H.globalPos(col, row)
if aperture then
local gc = H.call(aperture.ToGlobalColumn, col)
local gr = H.call(aperture.ToGlobalRow, row)
if type(gc) == "number" and type(gr) == "number" then
return gc, gr
end
end
return col + (originCol or 0), row + (originRow or 0)
end
local function clipStatus(col, row)
local m = mpc.clipMatrix
if not (m and m.HasClip) then
return 0
end
local gc, gr = H.globalPos(col, row)
local has = H.call(m.HasClip, gc, gr)
if not has then
return 0, gc, gr
end
if H.call(m.ClipIsPlaying, gc, gr) or H.call(m.ClipIsRecording, gc, gr) then
return 2, gc, gr
end
if H.call(m.ClipIsStopped, gc, gr) then
return 1, gc, gr
end
return 3, gc, gr
end
local function clipColour(col, row)
local p = clipProps and clipProps[col] and clipProps[col][row]
local c = H.propValue(p, "Colour")
if type(c) == "number" and c ~= 0 then
return c
end
local m = mpc.clipMatrix
if m and m.GetClipColour then
local gc, gr = H.globalPos(col, row)
local v = H.call(m.GetClipColour, gc, gr)
if type(v) == "number" then
return v
end
end
return 0x808080
end
local function addSpec(spec)
ledSpecs[#ledSpecs + 1] = spec
end
local function ledRGB(index, r, g, b)
index = tonumber(index)
if not index then
return
end
r, g, b = math.floor(tonumber(r) or 0), math.floor(tonumber(g) or 0), math.floor(tonumber(b) or 0)
if r < 0 then
r = 0
elseif r > 127 then
r = 127
end
if g < 0 then
g = 0
elseif g > 127 then
g = 127
end
if b < 0 then
b = 0
elseif b > 127 then
b = 127
end
local key = H.rgbKey(r, g, b)
if padCache[index] == key then
return
end
padCache[index] = key
addSpec(string.char(3, index % 128, r, g, b))
end
local function ledCol(index, colour)
ledRGB(index, colour[1], colour[2], colour[3])
end
local function ledOff(index)
ledRGB(index, 0, 0, 0)
end
local function flushLEDs()
if #ledSpecs == 0 then
return
end
local header = string.char(0x00, 0x20, 0x29, 0x02, 0x0D, 0x03)
local ok = pcall(function()
if #ledSpecs <= SYSEX_MAX_SPECS then
dev.midiOut.SendMIDISysex(header .. table.concat(ledSpecs), port)
else
local i = 1
while i <= #ledSpecs do
local chunk = {}
local n = 0
while i <= #ledSpecs and n < SYSEX_MAX_SPECS do
n = n + 1
chunk[n] = ledSpecs[i]
i = i + 1
end
dev.midiOut.SendMIDISysex(header .. table.concat(chunk), port)
end
end
end)
if not ok then
H.logOnce("sysex", "SendMIDISysex failed")
end
ledSpecs = {}
end
local function sendMini(command, ...)
local payload = { string.char(0x00, 0x20, 0x29, 0x02, 0x0D, command) }
for _, b in ipairs({ ... }) do
payload[#payload + 1] = string.char(b)
end
local ok = pcall(function()
dev.midiOut.SendMIDISysex(table.concat(payload), port)
end)
if not ok then
H.logOnce("mini" .. string.format("%02x", command), "sysex 0x" .. string.format("%02x", command) .. " failed")
end
end
local function sendMode(m)
sendMini(0x0E, m)
end
local function sendLayout(layout)
sendMini(0x00, layout)
end
local function sendFeedback(internal, external)
sendMini(0x0A, internal, external)
end
local function queryState()
sendMini(0x0E) -- mode readback
sendMini(0x00) -- layout readback
sendMini(0x0A) -- LED feedback readback
end
local SEGMENTS = {
["0"] = { a = true, b = true, c = true, d = true, e = true, f = true, g = false },
["1"] = { a = false, b = true, c = true, d = false, e = false, f = false, g = false },
["2"] = { a = true, b = true, c = false, d = true, e = true, f = false, g = true },
["3"] = { a = true, b = true, c = true, d = true, e = false, f = false, g = true },
["4"] = { a = false, b = true, c = true, d = false, e = false, f = true, g = true },
["5"] = { a = true, b = false, c = true, d = true, e = false, f = true, g = true },
["6"] = { a = true, b = false, c = true, d = true, e = true, f = true, g = true },
["7"] = { a = true, b = true, c = true, d = false, e = false, f = false, g = false },
["8"] = { a = true, b = true, c = true, d = true, e = true, f = true, g = true },
["9"] = { a = true, b = true, c = true, d = true, e = false, f = true, g = true },
}
local function tempoPad(col, row, colour)
if col >= 0 and col < GRID_COLS and row >= 0 and row < GRID_ROWS then
ledRGB(10 * (8 - row) + col + 1, colour[1], colour[2], colour[3])
end
end
local function drawDigit(ch, x0, y0, w, h, colour)
local seg = SEGMENTS[ch]
if not seg then
return
end
local mid = math.floor(h / 2)
if seg.a then
for c = 0, w - 1 do
tempoPad(x0 + c, y0, colour)
end
end
if seg.d then
for c = 0, w - 1 do
tempoPad(x0 + c, y0 + h - 1, colour)
end
end
if seg.g then
for c = 0, w - 1 do
tempoPad(x0 + c, y0 + mid, colour)
end
end
if seg.f then
for r = 0, mid do
tempoPad(x0, y0 + r, colour)
end
end
if seg.b then
for r = 0, mid do
tempoPad(x0 + w - 1, y0 + r, colour)
end
end
if seg.e then
for r = mid, h - 1 do
tempoPad(x0, y0 + r, colour)
end
end
if seg.c then
for r = mid, h - 1 do
tempoPad(x0 + w - 1, y0 + r, colour)
end
end
end
local function paintNumberGrid(value)
value = math.max(0, math.min(999, math.floor(value)))
for row = 0, GRID_ROWS - 1 do
for col = 0, GRID_COLS - 1 do
ledOff(10 * (8 - row) + col + 1)
end
end
local text
local widths = {}
if value >= 100 then
text = string.format("%3d", value)
widths[1] = (text:sub(1, 1) == "1") and 1 or 2
local remaining = GRID_COLS - widths[1]
widths[2] = math.floor(remaining / 2)
widths[3] = remaining - widths[2]
else
text = string.format("%2d", value)
widths[1] = 4
widths[2] = 4
end
local colours = { C.white, C.orange, C.blue }
local x0 = 0
for i = 1, #text do
drawDigit(text:sub(i, i), x0, 0, widths[i], GRID_ROWS, colours[#text - i + 1])
x0 = x0 + widths[i]
end
end
local function paintTempoGrid()
local bpm = math.floor(H.call(mpc.sequencer and mpc.sequencer.GetBPM) or 120)
paintNumberGrid(bpm)
end
local function paintSwingGrid()
local q = mpc.sequencer and mpc.sequencer.quantiser
local swing = math.floor(H.call(q and q.GetSwing) or 50)
paintNumberGrid(math.max(50, math.min(75, swing)))
end
local function paintAdjustGrid()
local colour = C.cyan
if adjustMode == "pan" then
colour = C.magenta
elseif adjustMode == "sends" then
colour = SEND_COLOURS[adjustSend] or C.yellow
end
local name = H.adjustPropName()
local trackCount = H.call(mpc.tracks and mpc.tracks.SizeNormalTracks) or GRID_COLS
for col = 0, GRID_COLS - 1 do
local gc = H.globalPos(col, 0)
local t = H.trackAt(gc)
if t and gc < trackCount then
local litCount
if adjustMode == "volume" then
local gain = H.propValue(t, "Volume")
local db = H.gainToDb(gain)
local row = H.dbToRow(db)
litCount = (db <= -60) and 0 or (GRID_ROWS - row)
else
local value = H.propValue(t, name) or 0
if type(value) ~= "number" then
value = 0
end
litCount = math.floor(value * GRID_ROWS + 0.5)
end
for row = 0, GRID_ROWS - 1 do
local idx = 10 * (8 - row) + col + 1
local fromBottom = 7 - row
if fromBottom < litCount then
ledCol(idx, colour)
else
ledCol(idx, C.dim)
end
end
else
for row = 0, GRID_ROWS - 1 do
ledOff(10 * (8 - row) + col + 1)
end
end
end
end
local paintAll -- forward declaration (defined below)
local exitPadsMode -- forward declaration (defined with the pad-mode helpers)
local closeGridStates -- forward declaration (defined with the pad-mode helpers)
local function qlinkAt(i)
local cs = mpc.controlSurface
local ql = cs and cs.qlinks
if not ql then
return nil
end
return ql[i]
end
local function qlinkCount()
local cs = mpc.controlSurface
local ql = cs and cs.qlinks
if not ql then
return 0
end
return H.call(ql.GetNumQLinks) or 0
end
local function qlinkPosition(i)
local q = qlinkAt(i)
if not q then
return 0
end
return H.call(q.GetPosition) or 0
end
local function touchQlink(q)
if q and type(q.Touch) == "function" then
pcall(q.Touch)
end
end
local qlinkTargetLogged = {} -- page-open diagnosis: one line per qlink
local QLINK_BANK_COLOURS = { C.cyan, C.magenta, C.yellow, C.blue }
local qlinkFlip = {}
local qlinkSeenStrings = {} -- i -> set of distinct value strings observed
local qlinkSeenPos = {} -- i -> { min = , max = }
local function qlinkTargetName(i)
local q = qlinkAt(i)
local name = H.call(q and q.GetTargetName)
if type(name) ~= "string" then
name = H.propValue(q, "TargetName")
end
return type(name) == "string" and name or ""
end
local function setQlinkPosition(i, pos)
local q = qlinkAt(i)
if not q then
return
end
if not qlinkTargetLogged[i] then
qlinkTargetLogged[i] = true
H.log(string.format("qlink %d target '%s'", i, qlinkTargetName(i)))
end
local before = H.call(q.GetValueString)
local posBefore = H.call(q.GetPosition) or 0
touchQlink(q)
if type(q.Twist) == "function" then
for _ = 1, 2 do
local delta = pos - (H.call(q.GetPosition) or 0)
if delta == 0 then
break
end
if delta > 127 then
delta = 127
elseif delta < -127 then
delta = -127
end
H.call(q.Twist, delta)
end
end
local afterTwist = H.call(q.GetValueString)
if afterTwist == before and type(q.SetValue) == "function" then
local v = H.call(q.GetValue)
if type(v) == "number" and posBefore ~= 0 then
H.call(q.SetValue, v * pos / posBefore)
end
H.call(q.SetPosition, pos)
elseif type(q.SetPosition) == "function" then
H.call(q.SetPosition, pos) -- keep the knob position in sync with the target
end
touchQlink(q)
local str = tostring(H.call(q.GetValueString) or "")
H.log(string.format("qlink %d = %d (%s)", i, pos, str))
if str ~= "" then
local seen = qlinkSeenStrings[i]
if not seen then
seen = {}
qlinkSeenStrings[i] = seen
end
seen[str] = true
local span = qlinkSeenPos[i]
if not span then
span = { min = pos, max = pos }
qlinkSeenPos[i] = span
else
if pos < span.min then
span.min = pos
end
if pos > span.max then
span.max = pos
end
end
local n = 0
for _ in pairs(seen) do
n = n + 1
end
if n == 2 and span.max - span.min >= 48 and not qlinkFlip[i] then
qlinkFlip[i] = true
H.log(string.format("qlink %d flip parameter", i))
end
end
end
local QLINK_BLOCKED_TARGETS = {
["SEQUENCE TEMPO"] = true, -- dedicated tempo page (arrows, repeat)
["CURRENT TRACK"] = true,
["TIME DIVISION"] = true,
["SEQUENCE LENGTH"] = true,
["REC ARM"] = true,
["SWING"] = true, -- dedicated swing page
["PLAYHEAD"] = true,
}
local function qlinkAssigned(i)
local name = qlinkTargetName(i)
return name ~= "" and not QLINK_BLOCKED_TARGETS[string.upper(name)]
end
local function qlinkColour(i)
return QLINK_BANK_COLOURS[math.floor(i / 4) + 1] or C.cyan
end
local QLINK_PAGE_GROUPS = {
[0] = { { 12, 8, 4, 0 }, { 13, 9, 5, 1 } }, -- MPC pages 1+2
[1] = { { 14, 10, 6, 2 }, { 15, 11, 7, 3 } }, -- MPC pages 3+4
}
local qlinkColumnMap = {}
local function buildQlinkColumnMap(page)
qlinkColumnMap = {}
local count = qlinkCount()
local groups = QLINK_PAGE_GROUPS[page or qlinkPage] or QLINK_PAGE_GROUPS[0]
for g = 1, 2 do
for rank, i in ipairs(groups[g]) do
if i < count and qlinkAssigned(i) then
qlinkColumnMap[4 * (g - 1) + rank - 1] = i
end
end
end
end
local function qlinkForColumn(col)
return qlinkColumnMap[col]
end
local function qlinkPageHasContent(page)
local count = qlinkCount()
for _, group in ipairs(QLINK_PAGE_GROUPS[page]) do
for _, i in ipairs(group) do
if i < count and qlinkAssigned(i) then
return true
end
end
end
return false
end
local function paintQlinkGrid()
buildQlinkColumnMap()
for col = 0, GRID_COLS - 1 do
local i = qlinkForColumn(col)
local assigned = i ~= nil
local pos = assigned and qlinkPosition(i) or 0
local colour = qlinkColour(i or 0)
local litCount = math.floor(pos / 127 * GRID_ROWS + 0.5)
for row = 0, GRID_ROWS - 1 do
local idx = 10 * (8 - row) + col + 1
local fromBottom = 7 - row
if not assigned then
ledOff(idx)
elseif qlinkFlip[i] then
if (pos >= 64 and row == 0) or (pos < 64 and row == GRID_ROWS - 1) then
ledCol(idx, colour)
else
ledCol(idx, C.dim)
end
elseif fromBottom < litCount then
ledCol(idx, colour)
else
ledCol(idx, C.dim)
end
end
end
end
local function handleQlinkPad(col, row)
buildQlinkColumnMap()
local i = qlinkForColumn(col)
if i == nil then
return
end
local target
if qlinkFlip[i] then
target = (row < GRID_ROWS / 2) and 127 or 0
else
target = math.floor((GRID_ROWS - row) / GRID_ROWS * 127 + 0.5)
end
setQlinkPosition(i, target)
qlinkCol = col
paintAll()
end
local function enterQlink()
if not H.requireProject("qlink page") then
return
end
local cs = mpc.controlSurface
if not (cs and cs.qlinks) then
H.logOnce("noqlinks", "qlink page unavailable: controlSurface.qlinks missing")
return
end
exitPadsMode() -- the Q-Link page needs the whole grid: any pads-mode note
closeGridStates() -- one canonical "close every other page" list
qlinkMode = true
qlinkPage = 0
qlinkCol = 0
qlinkTargetLogged = {}
qlinkFlip = {}
qlinkSeenStrings = {}
qlinkSeenPos = {}
buildQlinkColumnMap(0)
local map = {}
local assignedCount = 0
for c = 0, GRID_COLS - 1 do
local i = qlinkColumnMap[c]
if i then
assignedCount = assignedCount + 1
map[#map + 1] = (c + 1) .. "=" .. qlinkTargetName(i)
else
map[#map + 1] = (c + 1) .. "=-"
end
end
H.log("qlink page (" .. assignedCount .. " assigned): " .. table.concat(map, ", "))
paintAll()
end
local function exitQlink()
qlinkMode = false
H.log("qlink page off")
paintAll()
end
local function cycleQlinkPage()
if qlinkMode then
if qlinkPage == 0 and qlinkPageHasContent(1) then
qlinkPage = 1
H.log("qlink page 2")
paintAll()
else
exitQlink()
end
else
enterQlink()
end
end
local CLIP_BLINK_FAST = { [3] = true, [5] = true, [6] = true, [8] = true, [9] = true, [11] = true }
local function blinkPhase(fast)
if fast then
return blinkOn
end
return ticks % 10 < 5
end
local function paintClipSlot(col, row)
local p = clipProps and clipProps[col] and clipProps[col][row]
local state = tonumber(H.propValue(p, "State"))
if state == nil then
return false
end
local idx = 10 * (8 - row) + col + 1
if state < 2 then
if H.propValue(p, "Selected") == true then
ledCol(idx, C.available)
else
ledOff(idx)
end
return true
end
local r, g, b
if state >= 6 then
r, g, b = C.red[1], C.red[2], C.red[3]
elseif state >= 3 then
r, g, b = C.green[1], C.green[2], C.green[3]
else
r, g, b = H.argb(clipColour(col, row))
end
if state >= 3 and not blinkPhase(CLIP_BLINK_FAST[state]) then
r, g, b = H.scale7(r * 0.18), H.scale7(g * 0.18), H.scale7(b * 0.18)
end
ledRGB(idx, r, g, b)
return true
end
local function paintChromaticGrid()
local cs = mpc.controlSurface
local pads = cs and cs.pads
local virt = pads and pads.virtual
for padRow = 0, 7 do
for col = 0, 7 do
local idx = 10 * (padRow + 1) + col + 1
local i = padRow * 8 + col
local p = (virt and virt[i]) or (pads and pads[i])
local v = H.call(p and p.GetColour)
if type(v) ~= "number" then
v = H.propValue(p, "Colour")
end
if type(v) == "number" and v ~= 0 and v ~= -16777216 then
local r, g, b = H.argb(v)
ledRGB(idx, H.scale7(r), H.scale7(g), H.scale7(b))
else
ledRGB(idx, 0, 15, 30)
end
end
end
end
local function paintPadsGrid(poll)
if padsLayout == "pads64" then
paintChromaticGrid()
return
end
local quadrant = {}
for i = 0, 15 do
quadrant[10 * (math.floor(i / 4) + 1) + (i % 4) + 1] = true
end
for row = 0, GRID_ROWS - 1 do
for col = 0, GRID_COLS - 1 do
local idx = 10 * (8 - row) + col + 1
if not quadrant[idx] then
ledOff(idx)
end
end
end
local pads = mpc.controlSurface and mpc.controlSurface.pads
for i = 0, 15 do
local idx = 10 * (math.floor(i / 4) + 1) + (i % 4) + 1
if poll then
local p = pads and pads[i]
local v = H.call(p and p.GetColour)
if type(v) ~= "number" then
v = H.propValue(p, "Colour")
end
if v ~= padsColourCache[i] then
padsColourCache[i] = v
local r, g, b = H.argb(v)
ledRGB(idx, H.scale7(r), H.scale7(g), H.scale7(b))
end
elseif type(padsColourCache[i]) == "number" then
local r, g, b = H.argb(padsColourCache[i])
ledRGB(idx, H.scale7(r), H.scale7(g), H.scale7(b))
end
end
end
local function mixerNote(row, col)
return 10 * (8 - row) + col + 1
end
local function quantiserEnabled()
return H.truthy(H.propValue(mpc.sequencer and mpc.sequencer.quantiser, "Enabled"))
end
local function trackRecording(gc)
local m = mpc.clipMatrix
if m and m.TrackIsRecording then
local v = H.call(m.TrackIsRecording, gc)
if v ~= nil then
return v
end
end
return false
end
local function paintMixerGrid()
local sq = mpc.sequencer
local playing = H.truthy(sq and H.call(sq.IsPlaying) or H.propValue(sq, "Playing"))
local recording = H.truthy(H.propValue(sq, "RecordState"))
local overdub = H.truthy(H.propValue(sq, "OverdubState"))
local loop = H.truthy(H.propValue(sq, "Loop"))
local metronome = H.truthy(H.propValue(sq, "MetronomeEnabled"))
local projectOn = H.projectLoaded()
local trackCount = H.call(mpc.tracks and mpc.tracks.SizeNormalTracks) or GRID_COLS
local ct = mpc.tracks and mpc.tracks.currentTrack
local currentIdx = tonumber(H.propValue(ct, "Index"))
for row = 0, 1 do
for col = 0, GRID_COLS - 1 do
local key = MIX_STRIP_KEYS[row][col + 1]
local colour = C.off
if projectOn then
if key == "play" then
colour = (playing and C.green) or (loop and C.orange) or C.available
elseif key == "record" then
colour = (recording and C.red) or (overdub and C.orange) or C.available
elseif key == "stop" then
colour = C.available
elseif key == "tap" then
colour = C.available
elseif key == "click" then
colour = metronome and C.cyan or C.available
elseif key == "volume" then
colour = (adjustMode == "volume") and C.white or DIM_CYAN
elseif key == "pan" then
colour = (adjustMode == "pan") and C.white or DIM_MAGENTA
elseif key == "send" then
if adjustMode == "sends" then
colour = C.white
else
colour = DIM_SEND[adjustSend] or DIM_SEND[1]
end
elseif key == "tempo" then
colour = tempoMode and C.white or DIM_TEMPO
elseif key == "swing" then
colour = swingMode and C.yellow or DIM_YELLOW
elseif key == "qlink" then
colour = qlinkMode and C.white or DIM_QLINK
end
end
ledCol(mixerNote(row, col), colour)
end
end
for col = 0, GRID_COLS - 1 do
local gc = H.globalPos(col, 0)
local t = H.trackAt(gc)
local hasTrack = (t ~= nil) and gc < trackCount
local armed = hasTrack and H.truthy(H.propValue(t, "RecArm"))
if hasTrack and trackRecording(gc) then
ledCol(mixerNote(2, col), C.red)
elseif armed then
ledRGB(mixerNote(2, col), 60, 0, 0)
elseif hasTrack then
ledRGB(mixerNote(2, col), 0, 0, 45)
else
ledCol(mixerNote(2, col), C.off)
end
ledCol(mixerNote(3, col), hasTrack and C.available or C.off)
local muteCol, soloCol, armCol = C.off, C.off, C.off
if hasTrack then
muteCol = H.truthy(H.propValue(t, "Mute")) and C.orange or DIM_ORANGE
soloCol = H.truthy(H.propValue(t, "Solo")) and C.yellow or DIM_YELLOW
armCol = armed and C.red or DIM_RED
end
ledCol(mixerNote(4, col), muteCol)
ledCol(mixerNote(5, col), soloCol)
ledCol(mixerNote(6, col), armCol)
if hasTrack then
if currentIdx == gc then
ledCol(mixerNote(7, col), C.white)
else
local c = H.propValue(t, "Colour")
if type(c) == "number" then
local r, g, b = H.argb(c)
ledRGB(mixerNote(7, col), H.scale7(r * 0.6), H.scale7(g * 0.6), H.scale7(b * 0.6))
else
ledCol(mixerNote(7, col), C.available)
end
end
else
ledOff(mixerNote(7, col))
end
end
end
local function paintGrid()
if padsMode then
paintPadsGrid(ticks % 2 == 0)
return
end
if tempoMode then
paintTempoGrid()
return
end
if swingMode then
paintSwingGrid()
return
end
if qlinkMode then
paintQlinkGrid()
return
end
if adjustMode then
paintAdjustGrid()
return
end
if mixerMode then
paintMixerGrid()
return
end
for row = 0, GRID_ROWS - 1 do
for col = 0, GRID_COLS - 1 do
local idx = 10 * (8 - row) + col + 1
if not (clipProps and paintClipSlot(col, row)) then
local status = clipStatus(col, row)
if status == 0 then
ledOff(idx)
else
local c = clipColour(col, row)
local r, g, b = H.argb(c)
local k = 1.0
if status == 1 then
k = 0.18
elseif status == 3 then
k = blinkOn and 0.9 or 0.18
elseif status == 2 then
k = 0.95
end
ledRGB(idx, H.scale7(r * k), H.scale7(g * k), H.scale7(b * k))
end
end
end
end
end
local function paintScene()
for row = 0, 6 do
local idx = SCENE[row + 1]
local state = nil
if aperture and aperture.sceneProperties and aperture.sceneProperties[row] then
state = H.propValue(aperture.sceneProperties[row], "State")
end
if state == S.Playing or state == S.Recording then
ledCol(idx, C.green)
elseif state == S.WillPlay or state == S.WillRecord then
ledRGB(
idx,
blinkOn and C.green[1] or C.dim[1],
blinkOn and C.green[2] or C.dim[2],
blinkOn and C.green[3] or C.dim[3]
)
else
ledCol(idx, C.dim)
end
end
end
local padsLayoutAvailable -- forward declaration (defined with the pad-mode helpers)
local function paintTop()
local projectOn = H.projectLoaded()
local nudgeOn = adjustMode ~= nil or tempoMode or swingMode or qlinkMode
local pageColour = tempoMode and C.white
or (swingMode and C.yellow or (qlinkMode and qlinkColour(qlinkForColumn(0) or 0) or H.adjustColour()))
local arrows = (not projectOn and C.off) or (nudgeOn and pageColour or C.white)
ledCol(TOP.up, arrows)
ledCol(TOP.down, arrows)
ledCol(TOP.left, arrows)
ledCol(TOP.right, arrows)
ledCol(TOP.session, projectOn and C.white or C.off)
local drums = C.off
if padsMode then
drums = (padsLayout == "pads64") and C.cyan or C.white
elseif padsLayoutAvailable() and H.projectLoaded() then
drums = C.available
end
ledCol(TOP.drums, drums)
local keys = (keysPage and C.white)
or (projectOn and C.available or C.off)
ledCol(TOP.keys, keys)
local user = C.off
if qlinkMode then
user = C.white
elseif H.projectLoaded() and mpc.controlSurface ~= nil and mpc.controlSurface.qlinks ~= nil then
user = C.available
end
ledCol(TOP.user, user)
end
local function paintMenu()
if mixerMode then
ledCol(MENU, C.white)
elseif H.projectLoaded() then
ledCol(MENU, C.available)
else
ledCol(MENU, C.off)
end
end
paintAll = function()
paintGrid()
paintScene()
paintTop()
paintMenu()
flushLEDs()
end
local listeners = {} -- every property listened to; stopped by removeListeners
local gridListeners = {} -- the current window's clip slots; rebound on window moves
local function listen(prop, fn, store)
if prop and type(prop.listen) == "function" then
local ok = pcall(function()
prop:listen(fn, deviceName)
end)
if ok then
local target = store or listeners
target[#target + 1] = prop
end
end
end
local function repaintFn(fn)
return function(...)
local ok, err = pcall(fn, ...)
if not ok then
H.logOnce("listenererror", "listener error: " .. tostring(err))
end
end
end
local function stopProps(props)
for _, prop in ipairs(props) do
if prop and type(prop.stopListening) == "function" then
pcall(function()
prop:stopListening(deviceName)
end)
end
end
end
local function listenGrid()
stopProps(gridListeners)
gridListeners = {}
if not clipProps then
return
end
for col = 0, GRID_COLS - 1 do
for row = 0, GRID_ROWS - 1 do
local p = clipProps[col] and clipProps[col][row]
if p then
local repaint = repaintFn(function()
paintGrid()
flushLEDs()
end)
listen(p.Colour, repaint, gridListeners)
listen(p.State, repaint, gridListeners)
listen(p.Selected, repaint, gridListeners)
end
end
end
end
local function repaintState()
paintTop()
paintMenu()
if mixerMode then
paintMixerGrid()
end
flushLEDs()
end
local function followCurrentTrack(index)
listenGrid()
padCache = {}
paintAll()
end
local function listenAll()
if aperture and aperture.sceneProperties then
for row = 0, 7 do
local p = aperture.sceneProperties[row]
if p then
listen(
p.State,
repaintFn(function()
paintScene()
flushLEDs()
end)
)
end
end
end
local tracks = mpc.tracks and mpc.tracks.normalTracks
if tracks then
for i = 0, 7 do
local t = tracks[i]
if t then
local repaint = repaintFn(repaintState)
listen(t.Mute, repaint)
listen(t.Solo, repaint)
listen(t.RecArm, repaint)
end
end
end
local sq = mpc.sequencer
if sq then
local repaint = repaintFn(repaintState)
listen(sq.Playing, repaint)
listen(sq.RecordState, repaint)
listen(sq.OverdubState, repaint)
listen(sq.Loop, repaint)
listen(sq.quantiser and sq.quantiser.Enabled, repaint)
end
local ct = mpc.tracks and mpc.tracks.currentTrack
if ct then
listen(
ct.Index,
repaintFn(function(newIndex)
followCurrentTrack(newIndex)
end)
)
end
followCurrentTrack(H.propValue(ct, "Index"))
end
local function removeListeners()
stopProps(gridListeners)
gridListeners = {}
stopProps(listeners)
listeners = {}
end
closeGridStates = function()
adjustMode = nil
tempoMode = false
swingMode = false
qlinkMode = false
tempoHold = nil
swingHold = nil
mixerMode = false
lastPadCol, lastPadRow, lastPadTick = nil, nil, -100
end
local function padsModeNote(i)
return 10 * (math.floor(i / 4) + 1) + (i % 4) + 1
end
local function try(label, f, ...)
if type(f) ~= "function" then
return nil, label .. ": not a function"
end
local ok, r = pcall(f, ...)
if not ok then
return nil, label .. ": " .. tostring(r)
end
return r
end
local midiRoutingLogged = false
local function logMidiRouting()
if midiRoutingLogged or not H.projectLoaded() then
return
end
local tr = mpc.tracks
local n = H.call(tr and tr.SizeNormalTracks) or 0
H.log("midi routing probe (" .. n .. " normal tracks):")
for i = 0, math.min(n, 8) - 1 do
local name = try("name(" .. i .. ")", tr.GetCurrentTrackName, i)
if type(name) ~= "string" then
name = try("name#" .. i, tr.GetCurrentTrackName, tostring(i))
end
local key = (type(name) == "string" and name ~= "") and name or i
local port = try("port", tr.GetTrackInputPort, key)
local ch = try("ch", tr.GetTrackInputChannel, key)
local mon = try("mon", tr.GetTrackMonitorState, key)
local trig = try("trig", tr.IsTrackMidiTriggered, key)
local armed = H.truthy(H.propValue(H.trackAt(i), "RecArm"))
H.log(string.format(
"  [%d] %s: in=%s ch=%s mon=%s midiTrig=%s armed=%s",
i, tostring(name), tostring(port), tostring(ch), tostring(mon), tostring(trig), tostring(armed)
))
end
midiRoutingLogged = true
end
local MIDI_IN_ALL = 2147483645
local midiInNone = nil -- discovered once, cached across guard runs
local function trackInputKeys(tr, i)
local name = H.call(tr.GetCurrentTrackName, i)
if type(name) == "string" and name ~= "" then
return { i, name }
end
return { i }
end
local function guardTrackInputs()
local tr = mpc.tracks
if not (tr and type(tr.GetTrackInputPort) == "function" and type(tr.SetTrackInputPort) == "function") then
return
end
if not H.projectLoaded() then
return
end
local n = H.call(tr.SizeNormalTracks) or 0
for i = 0, n - 1 do
for _, key in ipairs(trackInputKeys(tr, i)) do
if H.call(tr.GetTrackInputPort, key) == MIDI_IN_ALL then
if midiInNone == nil then
for _, v in ipairs({ -1, -2 }) do
local ok = pcall(tr.SetTrackInputPort, key, v)
if ok and H.call(tr.GetTrackInputPort, key) == v then
midiInNone = v
H.log("midi guard: input 'none' sentinel is " .. v)
break
end
end
if midiInNone == nil then
H.logOnce("noguard", "midi guard: no 'none' sentinel accepted; tracks stay on All")
return
end
end
local ok = pcall(tr.SetTrackInputPort, key, midiInNone)
if ok and H.call(tr.GetTrackInputPort, key) == midiInNone then
H.log("midi guard: track [" .. i .. "] input All -> none")
end
end
end
end
end
local ppWatchUntil = 0 -- close the Pad Perform dialog for this many ticks after a press
local pressSurfaceButton -- forward declaration (defined below)
local function closePadPerformPopup()
if H.currentPopup() ~= "Pad Perform" then
return false
end
local popups = mpc.ui and mpc.ui.popups
local close = H.callable(popups, "CloseCurrentPopup")
if not close then
H.logOnce("nopopupclose", "Pad Perform dialog cannot be closed: ui.popups.CloseCurrentPopup missing")
return false
end
H.call(close)
H.log("pad perform dialog closed")
return true
end
local function watchPadPerformPopup()
if padPerformPageOurs() then
return -- our page stays open while keys owns the surface on a melodic track
end
if ticks < ppWatchUntil and H.currentPopup() == "Pad Perform" then
closePadPerformPopup()
end
end
local ppPressAt = nil -- tick deadline for a deferred padPerform toggle
local function deferPadPerformPress()
ppPressAt = ticks + 2
end
local function runDeferredPadPerform()
if not ppPressAt or ticks < ppPressAt then
return
end
ppPressAt = nil
if pressSurfaceButton("padPerform") then
ppWatchUntil = ticks + 40 -- a dialog arriving AFTER we left gets closed
H.log("pad perform toggled (deferred)")
else
H.logOnce("padperform", "pad perform unavailable: controlSurface.padPerform missing")
end
if not padPerformPageOurs() then
closePadPerformPopup() -- only a page we own stays open
end
end
local function dismissPadPerform()
local popup = H.currentPopup() == "Pad Perform"
if not popup and not keysPP then
return -- a pending deferred press (if any) still handles the toggle
end
ppPressAt = nil -- we take over: never toggle twice
keysPP = false
if pressSurfaceButton("padPerform") then
H.log("pad perform off (sweep)")
ppWatchUntil = ticks + 40 -- the press may reopen the dialog late
end
closePadPerformPopup()
end
pressSurfaceButton = function(name)
local press = H.callable(mpc.controlSurface and mpc.controlSurface[name], "Press")
if press then
H.call(press)
H.call(H.callable(mpc.controlSurface[name], "Release"))
return true
end
return false
end
padsLayoutAvailable = function()
local pads = dev.mappings and dev.mappings.pads
if not pads then
return false
end
local field = (padsLayout == "pads64") and "AddNoteToVirtualPad" or "AddNoteToMpcPad"
return H.callable(pads, field) ~= nil
end
exitPadsMode = function()
if keysPage then
keysPage = false -- the Pad Perform page stops being ours (predicate went false)
if pressSurfaceButton("main") then
H.log("keys: back to main")
end
if keysPP then
keysPP = false
deferPadPerformPress()
end
end
dismissPadPerform() -- evidence-based immediate sweep (cancels the deferral)
if not padsMode then
return
end
padsMode = false
local pads = dev.mappings and dev.mappings.pads
for _, b in ipairs(boundPadNotes) do
if b.pad then
H.call(pads and pads.RemoveNoteToMpcPad, 0, b.note, b.pad)
else
H.call(pads and pads.RemoveNoteToVirtualPad, 0, b.note)
end
end
boundPadNotes = {}
padsColourCache = {}
if padsLayout == "pads64" then
if pressSurfaceButton("bank1") then
H.log("pad bank reset (bank 1)")
else
H.logOnce("bankreset", "pad bank reset unavailable: controlSurface.bank1 missing")
end
end
H.log("pads mode off")
end
chromaticVirtualPad = function(padRow, col)
return padRow * 8 + col
end
local function enterPadsMode()
local m = dev.mappings and dev.mappings.script
local pads = dev.mappings and dev.mappings.pads
if not (m and pads and m.AddNoteToScript) then
H.logOnce("padsmode", "pads mode unavailable: mappings.pads missing")
return
end
if padsLayout == "pads64" and type(pads.AddNoteToVirtualPad) ~= "function" then
H.logOnce("padschromatic", "chromatic layout unavailable: AddNoteToVirtualPad missing")
return
end
if padsLayout == "drum" and type(pads.AddNoteToMpcPad) ~= "function" then
H.logOnce("padsmode", "pads mode unavailable: AddNoteToMpcPad missing")
return
end
padsMode = true
padsColourCache = {}
boundPadNotes = {}
if padsLayout == "drum" then
if pressSurfaceButton("main") then
H.log("pad view: main screen")
else
H.logOnce("padview", "pad view reset unavailable: controlSurface.main missing")
end
end
if padsLayout == "pads64" then
for padRow = 0, 7 do
for col = 0, 7 do
local note = 10 * (padRow + 1) + col + 1
H.call(pads.AddNoteToVirtualPad, 0, note, chromaticVirtualPad(padRow, col))
boundPadNotes[#boundPadNotes + 1] = { note = note }
end
end
else
for i = 0, 15 do
local note = padsModeNote(i)
H.call(pads.AddNoteToMpcPad, 0, note, i)
boundPadNotes[#boundPadNotes + 1] = { note = note, pad = i }
end
end
H.log("pads mode on (" .. padsLayout .. ")")
if padsLayout == "pads64" then
H.logOnce("tip8x8", "tip: switch the MPC's pad view to 8x8 64 Pads for full colours")
end
end
local function firstLayoutForTrack()
local t = mpc.tracks and mpc.tracks.currentTrack
local trackType = H.propValue(t, "Type")
if type(trackType) == "string" and trackType ~= "" and trackType ~= "Drum" then
return "pads64", trackType
end
return "drum", trackType
end
trackIsMelodicFn = function()
return firstLayoutForTrack() == "pads64"
end
local function togglePadsMode()
if not padsMode and not H.requireProject("pads mode") then
return
end
logMidiRouting()
if not padsMode then
local layout, trackType = firstLayoutForTrack()
padsLayout = layout
padsSwitched = false
H.log("track type " .. tostring(trackType or "?") .. " -> " .. layout)
exitPadsMode() -- clears a stray keysPage (degraded padPerform entry)
closeGridStates()
enterPadsMode()
if padsMode then
paintPadsGrid(true) -- immediate mirror, independent of the tick parity
end
return
end
if not padsSwitched then
exitPadsMode()
padsLayout = (padsLayout == "drum") and "pads64" or "drum"
padsSwitched = true
enterPadsMode()
if padsMode then
paintPadsGrid(true)
end
return
end
exitPadsMode()
paintAll()
end
local function toggleKeysPage()
if keysPage then
exitPadsMode() -- also leaves the Pad Perform page (MPC back on Main)
paintAll()
return
end
if not H.requireProject("keys page") then
return
end
local layout, trackType = firstLayoutForTrack()
exitPadsMode()
closeGridStates()
padsLayout = "drum" -- Pad Perform and plain kit play both drive the 16 pads
padsSwitched = true -- one more Drums press exits instead of flipping
enterPadsMode()
if not padsMode then
H.logOnce("padperform", "keys page unavailable: pads mapping missing")
paintAll()
return
end
if layout == "pads64" then
keysPage, keysPP = true, true
deferPadPerformPress()
H.log("keys page: pad perform chords (" .. tostring(trackType) .. ")")
else
keysPage, keysPP = true, false
H.log("keys page: kit play (drum track)")
end
paintAll()
end
local function closeAllPages()
exitPadsMode()
closeGridStates()
end
local function doClip(col, row)
if not aperture then
return
end
H.call(aperture.SelectClip, col, row)
H.call(aperture.TriggerClip, col, row)
H.log(string.format("TriggerClip(%d,%d)", col, row))
end
local function doScene(row)
if not aperture then
return
end
H.call(aperture.TriggerRow, row)
H.log("TriggerRow(" .. row .. ")")
end
local function applyFunction(fn, idx)
local t = mpc.tracks and mpc.tracks.normalTracks and mpc.tracks.normalTracks[idx]
if not t then
H.logOnce("track", "no track " .. tostring(idx))
return
end
if fn == "recArm" then
local v = H.propValue(t, "RecArm")
H.call(t.SetRecArm, not v)
H.log("SetRecArm(" .. tostring(not v) .. ") track " .. idx)
elseif fn == "mute" then
local v = H.propValue(t, "Mute")
H.call(t.SetMute, not v)
H.log("SetMute(" .. tostring(not v) .. ") track " .. idx)
elseif fn == "solo" then
local v = H.propValue(t, "Solo")
H.call(t.SetSolo, not v)
H.log("SetSolo(" .. tostring(not v) .. ") track " .. idx)
elseif fn == "stopClip" then
H.call(aperture and aperture.StopClipsOnTrack, idx)
H.log("StopClipsOnTrack(" .. idx .. ")")
else
H.log(fn .. ": unsupported track function " .. idx)
end
end
local function selectTrack(col, gc)
local setCurrent = H.callable(mpc.tracks, "SetCurrentTrack")
if setCurrent then
H.call(setCurrent, gc)
H.log("SetCurrentTrack(" .. gc .. ")")
end
if aperture then
H.call(aperture.SelectTrack, col)
end
end
local function setTrackValue(idx, name, v)
local t = H.trackAt(idx)
if not t then
H.logOnce("track", "no track " .. tostring(idx))
return
end
local p = t[name]
if p == nil then
H.logOnce("prop" .. name, name .. " MISSING on track " .. tostring(idx))
return
end
local value = H.clamp01(v)
local ok = pcall(function()
p.value = value
end)
if not ok then
H.logOnce("set" .. name, "set " .. name .. " failed on track " .. tostring(idx))
return
end
H.log(string.format("%s track %d = %.3f", name, idx, value))
end
local function setTrackVolumeDB(idx, db)
local t = H.trackAt(idx)
if not t then
H.logOnce("track", "no track " .. tostring(idx))
return
end
local p = t.VolumeDB
if p ~= nil then
local ok = pcall(function()
p.value = db
end)
if ok then
H.log(string.format("VolumeDB track %d = %s", idx, tostring(db)))
return
end
end
setTrackValue(idx, "Volume", H.dbToGain(db))
end
local function changeTempo(delta)
if not H.requireProject("tempo") then
return
end
local sq = mpc.sequencer
local bpm = H.call(sq and sq.GetBPM) or 120
bpm = math.max(20, math.min(300, math.floor(bpm + delta + 0.5)))
H.call(sq and sq.SetBPM, bpm)
H.log("tempo: " .. bpm .. " BPM")
paintGrid()
paintTop()
flushLEDs()
end
local function changeSwing(delta)
if not H.requireProject("swing") then
return
end
local q = mpc.sequencer and mpc.sequencer.quantiser
local swing = H.call(q and q.GetSwing) or 50
swing = math.max(50, math.min(75, math.floor(swing + delta + 0.5)))
H.call(q and q.SetSwing, swing)
H.log("swing: " .. swing .. "%")
paintGrid()
paintTop()
flushLEDs()
end
local function nudgeAdjust(delta)
if not adjustMode then
return
end
local gc = H.globalPos(adjustCol, 0)
local name = H.adjustPropName()
if not name then
return
end
if adjustMode == "volume" then
local db = H.gainToDb(H.propValue(H.trackAt(gc), "Volume"))
local row = H.dbToRow(db)
if delta > 0 then
row = math.max(0, row - 1)
else
row = math.min(GRID_ROWS - 1, row + 1)
end
setTrackVolumeDB(gc, VOLUME_DB[row])
paintAll()
return
end
local cur = H.propValue(H.trackAt(gc), name)
if type(cur) ~= "number" then
cur = 0
end
setTrackValue(gc, name, cur + delta)
paintAll()
end
local function enterAdjust(newMode, sendIdx)
if not H.requireProject(newMode .. " menu") then
return
end
exitPadsMode() -- the fader menus need the whole grid
closeGridStates() -- one canonical "close every other page" list
adjustMode = newMode
adjustCol = 0
lastPadCol, lastPadRow, lastPadTick = nil, nil, -100
if newMode == "sends" then
adjustSend = sendIdx or adjustSend or 1
end
H.log("menu " .. newMode .. (newMode == "sends" and (" send " .. adjustSend) or ""))
paintAll()
end
local function exitAdjust()
if adjustMode then
adjustMode = nil
lastPadCol, lastPadRow, lastPadTick = nil, nil, -100
H.log("menu off")
paintAll()
end
end
local function handleAdjustPad(col, row)
if not adjustMode then
return
end
local gc = H.globalPos(col, 0)
if adjustMode == "volume" then
setTrackVolumeDB(gc, VOLUME_DB[row])
lastPadCol, lastPadRow, lastPadTick = col, row, ticks
adjustCol = col
paintAll()
return
end
local value = (GRID_ROWS - row) / GRID_ROWS
if col == lastPadCol and row == lastPadRow and ticks - lastPadTick <= 2 then
if row == GRID_ROWS - 1 then
value = 0
end
end
lastPadCol, lastPadRow, lastPadTick = col, row, ticks
adjustCol = col
local name = H.adjustPropName()
if name then
setTrackValue(gc, name, value)
paintAll()
end
end
local function doTapTempo()
local now = H.call(dev.timer and dev.timer.Now)
local useMs = type(now) == "number"
if not useMs then
now = ticks
end
local function diff(a, b)
local d = a - b
if useMs and d < 0 then
d = d + 4294967296 -- 32-bit wrap
end
return d
end
if #tapTicks > 0 and diff(now, tapTicks[#tapTicks]) > (useMs and 2000 or 40) then
tapTicks = {}
end
tapTicks[#tapTicks + 1] = now
if #tapTicks > 5 then
table.remove(tapTicks, 1)
end
if #tapTicks < 2 then
H.log("tap tempo: first tap")
return
end
local total = 0
for i = 2, #tapTicks do
total = total + diff(tapTicks[i], tapTicks[i - 1])
end
local avg = total / (#tapTicks - 1)
local bpm = (useMs and 60000 or 1200) / avg
bpm = math.max(20, math.min(300, bpm))
bpm = math.floor(bpm + 0.5) -- MPC BPM is an integer
local setBPM = H.callable(mpc.sequencer, "SetBPM")
if setBPM then
H.call(setBPM, bpm)
H.log(string.format("tap tempo: %d BPM (%.1f ms)", bpm, avg))
else
H.logOnce("tapbpm", "tap tempo unavailable: sequencer.SetBPM missing")
end
end
local function doMetronomeToggle()
local sq = mpc.sequencer
local me = H.propValue(sq, "MetronomeEnabled")
if sq and type(sq.SetMetronomeEnabled) == "function" then
H.call(sq.SetMetronomeEnabled, not me)
H.log("Metronome " .. tostring(not me))
else
H.logOnce("metronome", "metronome unavailable: sequencer.SetMetronomeEnabled missing")
end
end
local function doTransport(fn)
if not H.requireProject("transport") then
return
end
local sq = mpc.sequencer
if fn == "play" then
local playing = sq and H.call(sq.IsPlaying) or H.propValue(sq, "Playing")
if not playing then
H.call(sq and sq.Play)
H.log("Play")
end
elseif fn == "stop" then
local playing = sq and H.call(sq.IsPlaying) or H.propValue(sq, "Playing")
if playing then
H.call(sq and sq.Stop)
H.log("Stop")
else
if H.callable(sq, "JumpToBeginning") then
H.call(sq.JumpToBeginning)
H.log("Locate zero")
else
H.logOnce("locate", "locate zero unavailable: sequencer.JumpToBeginning missing")
end
end
end
end
local function recordArmed()
return H.truthy(H.propValue(mpc.sequencer, "RecordState"))
end
local function doRecordToggle()
if not H.requireProject("record") then
return
end
local armed = recordArmed()
if pressSurfaceButton("record") then
H.log("record: " .. (armed and "disarmed" or "armed"))
return
end
local name = armed and "RecordOff" or "Record"
local f = H.callable(mpc.sequencer, name)
if not f then
H.logOnce("record", "record unavailable: sequencer." .. name .. " missing")
return
end
H.call(f)
H.log("record: " .. (armed and "disarmed" or "armed"))
end
local function moveWindow(dir, n)
if not aperture then
return
end
local fn = ({ left = "MoveLeft", right = "MoveRight", up = "MoveUp", down = "MoveDown" })[dir]
if fn then
H.call(aperture[fn], n)
H.log(fn .. "(" .. n .. ")")
padCache = {}
listenGrid() -- the slot properties follow the window: rebind, then repaint
paintAll()
end
end
local function enterMixer()
if not H.requireProject("mixer menu") then
return
end
exitPadsMode() -- the mixer needs the whole grid
closeGridStates() -- one canonical "close every other page" list
mixerMode = true
H.log("mixer menu")
paintAll()
end
local function exitMixer()
if not mixerMode then
return
end
mixerMode = false
H.log("mixer menu off")
paintAll()
end
local function toggleMixer()
if mixerMode then
exitMixer()
else
enterMixer()
end
end
local function toggleTempoPage()
if not tempoMode and not H.requireProject("tempo page") then
return
end
exitPadsMode() -- the tempo page needs the whole grid
exitMixer()
closeGridStates() -- one canonical "close every other page" list
tempoMode = not tempoMode
tempoHold = nil
if tempoMode then
H.log("tempo page: " .. tostring(H.call(mpc.sequencer and mpc.sequencer.GetBPM)) .. " BPM")
else
H.log("tempo page off")
end
paintAll()
flushLEDs()
end
local function toggleSwingPage()
if not swingMode and not H.requireProject("swing page") then
return
end
exitPadsMode() -- the swing page needs the whole grid
exitMixer()
closeGridStates() -- one canonical "close every other page" list
swingMode = not swingMode
swingHold = nil
if swingMode then
H.log(
"swing page: "
.. tostring(H.call(mpc.sequencer and mpc.sequencer.quantiser and mpc.sequencer.quantiser.GetSwing))
.. "%"
)
else
H.log("swing page off")
end
paintAll()
flushLEDs()
end
local function startTrackRecording(col, gc)
local t = H.trackAt(gc)
if not t then
return
end
selectTrack(col, gc)
if not H.truthy(H.propValue(t, "RecArm")) then
H.call(t.SetRecArm, true)
end
local m = mpc.clipMatrix
if not (m and m.HasClip and aperture) then
H.logOnce("recslot", "track record: clipMatrix.HasClip missing")
return
end
for row = 0, GRID_ROWS - 1 do
local gC, gR = H.globalPos(col, row)
local has = H.call(m.HasClip, gC, gR)
if not has then
H.call(aperture.TriggerClip, col, row)
H.log(string.format("track record: TriggerClip(%d,%d) on armed track", col, row))
return
end
end
H.logOnce("recfull", "track record: no empty slot in the window for track " .. gc)
end
local function handleMixerPad(col, row)
if row >= 2 then
if not H.requireProject("mixer track row") then
return
end
local gc = H.globalPos(col, 0)
if row == 7 then
selectTrack(col, gc)
elseif row == 6 then
applyFunction("recArm", gc)
elseif row == 5 then
applyFunction("solo", gc)
elseif row == 4 then
applyFunction("mute", gc)
elseif row == 3 then
H.call(aperture and aperture.StopClipsOnTrack, gc)
H.log("StopClipsOnTrack(" .. gc .. ")")
elseif row == 2 then
if trackRecording(gc) then
H.call(aperture and aperture.StopClipsOnTrack, gc)
H.log("StopClipsOnTrack(" .. gc .. ") (recording)")
else
startTrackRecording(col, gc)
end
end
paintAll()
return
end
local key = MIX_STRIP_KEYS[row][col + 1]
if not key then
return
end
if key == "play" then
doTransport("play")
elseif key == "record" then
doRecordToggle()
elseif key == "stop" then
doTransport("stop")
elseif key == "tap" then
doTapTempo()
elseif key == "click" then
doMetronomeToggle()
elseif key == "volume" then
if adjustMode == "volume" then
exitAdjust()
else
enterAdjust("volume")
end
elseif key == "pan" then
if adjustMode == "pan" then
exitAdjust()
else
enterAdjust("pan")
end
elseif key == "send" then
if adjustMode == "sends" then
adjustSend = (adjustSend % 4) + 1
H.log("send " .. adjustSend)
paintAll()
else
enterAdjust("sends")
end
elseif key == "tempo" then
toggleTempoPage()
elseif key == "swing" then
toggleSwingPage()
elseif key == "qlink" then
cycleQlinkPage()
end
paintAll()
end
local function noteIndex(note)
if note >= GRID_NOTE0 and note <= GRID_NOTE0 + 77 then
local i = note - GRID_NOTE0
local padRow = math.floor(i / 10)
local col = i % 10
if col < 8 and padRow < 8 then
return col, 7 - padRow -- col, MPC row (0 = top)
end
end
return nil
end
function LaunchpadMiniMK3.HandleMIDINoteOn(channel, note, velocity)
if channel ~= 0 then
return
end
local col, row = noteIndex(note)
if col then
if padsMode then
return
end
if velocity > 0 then
if mixerMode then
handleMixerPad(col, row)
elseif adjustMode then
handleAdjustPad(col, row)
elseif qlinkMode then
handleQlinkPad(col, row)
elseif not tempoMode and not swingMode then
doClip(col, row)
end
end
return
end
end
function LaunchpadMiniMK3.HandleMIDINoteOff(_channel, _note, _velocity)
end
local function ccRelease(cc)
if cc == TOP.up or cc == TOP.down then
tempoHold = nil
swingHold = nil
end
end
local function ccUpDown(delta)
if tempoMode then
tempoHold = (delta > 0) and TOP.up or TOP.down
tempoHoldTicks = 0
changeTempo(delta)
elseif swingMode then
swingHold = (delta > 0) and TOP.up or TOP.down
swingHoldTicks = 0
changeSwing(delta)
elseif adjustMode then
nudgeAdjust(delta / 8)
elseif qlinkMode then
if qlinkPage == 0 and qlinkPageHasContent(1) then
qlinkPage = 1
H.log("qlink page 2")
paintAll()
elseif qlinkPage == 1 then
qlinkPage = 0
H.log("qlink page 1")
paintAll()
end
elseif padsMode then
return
else
moveWindow((delta > 0) and "up" or "down", 1)
end
end
local PRESS = {
[TOP.up] = function()
ccUpDown(1)
end,
[TOP.down] = function()
ccUpDown(-1)
end,
[TOP.left] = function()
if adjustMode == "sends" then
adjustSend = ((adjustSend - 2) % 4) + 1
H.log("send " .. adjustSend)
paintAll()
return
end
if adjustMode or tempoMode or swingMode or qlinkMode or padsMode then
return
end
moveWindow("left", 1)
end,
[TOP.right] = function()
if adjustMode == "sends" then
adjustSend = (adjustSend % 4) + 1
H.log("send " .. adjustSend)
paintAll()
return
end
if adjustMode or tempoMode or swingMode or qlinkMode or padsMode then
return
end
moveWindow("right", 1)
end,
[TOP.session] = function()
dismissPadPerform() -- a stuck Pad Perform must never block the escape
closeAllPages()
H.log("session: clip grid")
paintAll()
end,
[TOP.drums] = function()
dismissPadPerform() -- a chord-mangled surface must not leak into pads mode
togglePadsMode()
paintAll()
end,
[TOP.keys] = toggleKeysPage,
[TOP.user] = function()
dismissPadPerform()
cycleQlinkPage()
end,
}
for row = 0, 6 do
local sceneRow = row
PRESS[SCENE[sceneRow + 1]] = function()
doScene(sceneRow)
end
end
PRESS[MENU] = function()
dismissPadPerform()
if adjustMode or tempoMode or swingMode or qlinkMode then
closeAllPages()
H.log("pages off")
paintAll()
return
end
toggleMixer()
end
function LaunchpadMiniMK3.HandleMIDICC(channel, cc, value)
if channel ~= 0 then
return
end
if value == 0 then
ccRelease(cc)
return
end
local action = PRESS[cc]
if action then
action()
return
end
H.log("unmapped CC " .. cc .. " value " .. value)
end
function LaunchpadMiniMK3.HandleMIDISysex(bytes)
if type(bytes) ~= "string" then
return
end
if bytes:byte(1) == 0xF0 then
bytes = bytes:sub(2)
end
if bytes:byte(-1) == 0xF7 then
bytes = bytes:sub(1, -2)
end
if
bytes:byte(1) == 0x7E
and bytes:byte(3) == 0x06
and bytes:byte(4) == 0x02
and bytes:sub(5, 7) == string.char(0x00, 0x20, 0x29)
and bytes:byte(8) == 0x13
then
local ver = {}
for i = 12, math.min(15, #bytes) do
ver[#ver + 1] = tostring(bytes:byte(i))
end
H.logOnce("firmware", "firmware: " .. (#ver > 0 and table.concat(ver, ".") or "unknown"))
end
if bytes:sub(1, 6) == string.char(0x00, 0x20, 0x29, 0x02, 0x0D) and #bytes >= 7 then
local command = bytes:byte(6)
if command == 0x0E and #bytes >= 7 then
local m = bytes:byte(7)
if priorMode == nil and m ~= 0x01 then
priorMode = m
H.log(string.format("prior mode 0x%02x", m))
end
elseif command == 0x00 and #bytes >= 7 then
local layout = bytes:byte(7)
if priorLayout == nil and layout ~= 0x7F then
priorLayout = layout
H.log(string.format("prior layout 0x%02x", layout))
end
elseif command == 0x0A and #bytes >= 8 then
if priorFeedback == nil then
priorFeedback = { bytes:byte(7), bytes:byte(8) }
end
end
end
end
function LaunchpadMiniMK3.HandleTimer()
ticks = ticks + 1
if keysPage and keysPP and not trackIsMelodicFn() then
H.log("keys page: track is not melodic anymore - chords off, kit play")
dismissPadPerform()
end
runDeferredPadPerform()
watchPadPerformPopup()
if not midiRoutingLogged and ticks % 10 == 0 then
logMidiRouting()
if midiRoutingLogged then
guardTrackInputs()
end
end
if ticks % 5 == 0 then
blinkOn = not blinkOn
end
if tempoMode and tempoHold then
tempoHoldTicks = tempoHoldTicks + 1
local interval = tempoHoldTicks < 10 and 6 or (tempoHoldTicks < 20 and 3 or 1)
if tempoHoldTicks % interval == 0 then
changeTempo(tempoHold == TOP.up and 1 or -1)
end
end
if swingMode and swingHold then
swingHoldTicks = swingHoldTicks + 1
local interval = swingHoldTicks < 10 and 6 or (swingHoldTicks < 20 and 3 or 1)
if swingHoldTicks % interval == 0 then
changeSwing(swingHold == TOP.up and 1 or -1)
end
end
if modeQuerySent and not programmerEntered and ticks >= 1 then
sendMode(0x01)
programmerEntered = true
sendFeedback(0x00, 0x01)
padCache = {}
H.log("programmer mode")
end
if aperture and not clipProps then
for _, n in ipairs({ "GetOriginX", "GetColumn", "GetX" }) do
local v = H.call(aperture[n])
if type(v) == "number" then
originCol = v
break
end
end
for _, n in ipairs({ "GetOriginY", "GetRow", "GetY" }) do
local v = H.call(aperture[n])
if type(v) == "number" then
originRow = v
break
end
end
end
if ticks % 40 == 0 then
padCache = {}
if padsMode then
padsColourCache = {} -- force a full quadrant resend every 2 s
end
guardTrackInputs() -- new tracks default to input All: move them off it
end -- resend everything every 2 s
paintAll()
end
function LaunchpadMiniMK3.OnLoad()
adjustMode = nil
adjustSend = 1
tempoMode = false
swingMode = false
qlinkMode = false
qlinkPage = 0
qlinkCol = 0
padsMode = false
padsLayout = "drum"
padsSwitched = false
keysPage = false
tempoHold = nil
swingHold = nil
padsColourCache = {}
mixerMode = false
aperture = dev.clipMatrixAperture or (mpc.clipMatrix and mpc.clipMatrix.clipMatrixAperture)
clipProps = (aperture and aperture.clipProperties)
or dev.clipProperties
or (mpc.clipMatrix and mpc.clipMatrix.clipProperties)
if aperture then
H.call(aperture.SetColumns, 8)
H.call(aperture.SetRows, 8)
H.call(aperture.SetLabel, "LPMINI")
H.call(aperture.SetFollowsTUI, false)
H.call(aperture.Show)
H.log("aperture ok")
else
H.logOnce("noaperture", "aperture MISSING: clip surface disabled")
end
if clipProps then
H.log("clipProperties ok")
else
H.logOnce("noclips", "clipProperties MISSING")
end
local m = dev.mappings and dev.mappings.script
if m then
for padRow = 0, 7 do
for col = 0, 7 do
H.call(m.AddNoteToScript, 0, 10 * (padRow + 1) + col + 1)
end
end
local ccs = { 19, 29, 39, 49, 59, 69, 79, 89, 91, 92, 93, 94, 95, 96, 97, 98 }
for _, cc in ipairs(ccs) do
H.call(m.AddCCToScript, 0, cc)
end
H.call(m.SetHandleSysex, true)
end
queryState()
modeQuerySent = true
local okProbe = pcall(function()
dev.midiOut.SendMIDISysex(string.char(0x7E, 0x7F, 0x06, 0x01), port)
end)
if not okProbe then
H.logOnce("fwprobe", "firmware probe failed")
end
listenAll()
paintAll()
H.call(dev.timer and dev.timer.Start, 50)
H.log("loaded")
H.log(
"engine mode: "
.. tostring(
H.propValue(mpc.engineMode, "CurrentMode") or H.call(H.callable(mpc.engineMode, "GetCurrentMode"))
)
.. " popup: "
.. H.currentPopup()
)
end
function LaunchpadMiniMK3.OnUnload()
H.call(dev.timer and dev.timer.Stop)
removeListeners()
exitPadsMode() -- hand the pad-mode notes back to the script before unmapping
padsMode = false
padsColourCache = {}
adjustMode = nil
adjustSend = 1
tempoMode = false
swingMode = false
qlinkMode = false
qlinkPage = 0
qlinkCol = 0
mixerMode = false
padsSwitched = false
keysPage = false
tempoHold = nil
swingHold = nil
local m = dev.mappings and dev.mappings.script
if m then
for padRow = 0, 7 do
for col = 0, 7 do
H.call(m.RemoveNoteToScript, 0, 10 * (padRow + 1) + col + 1)
end
end
local ccs = { 19, 29, 39, 49, 59, 69, 79, 89, 91, 92, 93, 94, 95, 96, 97, 98 }
for _, cc in ipairs(ccs) do
H.call(m.RemoveCCToScript, 0, cc)
end
end
for padRow = 0, 7 do
for col = 0, 7 do
ledOff(10 * (padRow + 1) + col + 1)
end
end
for _, cc in ipairs({ 19, 29, 39, 49, 59, 69, 79, 89, 91, 92, 93, 94, 95, 96, 97, 98 }) do
ledOff(cc)
end
flushLEDs()
if programmerEntered then
if priorFeedback then
sendFeedback(priorFeedback[1], priorFeedback[2])
else
sendFeedback(0x01, 0x01)
end
if priorMode ~= 0x01 then
sendMode(0x00)
sendLayout(priorLayout or 0x04)
H.log("restored live mode")
end
end
if aperture then
H.call(aperture.Hide)
end
H.log("unloaded")
end
LaunchpadMiniMK3.ACTIONS = ACTIONS
LaunchpadMiniMK3.PALETTE = C
LaunchpadMiniMK3.MIXER = MIXER
LaunchpadMiniMK3.STATE = function()
return {
padsMode = padsMode,
padsLayout = padsLayout,
padsSwitched = padsSwitched,
keysPage = keysPage,
mixerMode = mixerMode,
adjustMode = adjustMode,
adjustSend = adjustSend,
tempoMode = tempoMode,
swingMode = swingMode,
qlinkMode = qlinkMode,
qlinkPage = qlinkPage,
boundPadNotes = #boundPadNotes,
}
end
